import './src/style/global.css';
import '@fontsource/playfair-display/400-italic.css';
import '@fontsource/playfair-display/700.css';
import '@fontsource/sora/300.css';
import '@fontsource/sora/600.css';
import 'react-multi-carousel/lib/styles.css';
